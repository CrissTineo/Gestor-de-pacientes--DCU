﻿using DBservicios;
using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ServiceLayer
{
    public class ServicioPacientes
    {
        private DBservicioPacientes dBservicioPacientes;
        public ServicioPacientes(SqlConnection connection)
        {
            dBservicioPacientes = new DBservicioPacientes(connection);
        }
        public bool AddPaciente(MirrorPacientes item)
        {
            return dBservicioPacientes.AddDBPaciente(item);
        }
        public bool Editpaciente(MirrorPacientes item)
        {
            return dBservicioPacientes.EditDBpaciente(item);
        }
        public bool DeletePaciente(int id) 
        {
            return dBservicioPacientes.DeleteDBpacientes(id);
        }
        public bool AddPhoto(string destination, int id) 
        {
            return dBservicioPacientes.AddDBPhoto(destination, id);
        }
        public int GetLastId() 
        {
            return dBservicioPacientes.GetDBLastId();
        }
        public MirrorPacientes GetPaciente(int id) 
        {
            return dBservicioPacientes.GetDBpaciente(id);            
        }
        public List<MirrorPacientes> GetDBpacienteByCed(string ced)
        {
            return dBservicioPacientes.GetDBpacienteByCed(ced);
        }
        public DataTable GetAllPacientes() 
        {
            return dBservicioPacientes.GetDBAllPacientes();
        }
    }
}
