﻿using DBservicios;
using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ServiceLayer
{
    public class ServicioPl
    {
        private DBservicioPL dBserviciosPl;
        public ServicioPl(SqlConnection connection) 
        {
            dBserviciosPl = new DBservicioPL(connection);
        }
        public bool AddPl(MirrorPruebaLab item) 
        {
            return dBserviciosPl.AddDBPl(item);
        }
        public bool EditPl(MirrorPruebaLab item) 
        {
            return dBserviciosPl.EditDBPl(item);
        }
        public bool DeletePl(int id) 
        {
            return dBserviciosPl.DeleteDBPl(id);
        }
        public MirrorPruebaLab GetPl(int id) 
        {
            return dBserviciosPl.GetDBPl(id);
        }
        public DataTable GetAllPl() 
        {
            return dBserviciosPl.GetAllDBPl();
        }
    }
}
