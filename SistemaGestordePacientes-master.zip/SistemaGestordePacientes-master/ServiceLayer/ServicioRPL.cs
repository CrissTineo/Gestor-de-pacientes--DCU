﻿using DBservicios;
using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ServiceLayer
{
    public class ServicioRPL
    {
        private DBservicioRPL dBsercivioRPL;

        public ServicioRPL(SqlConnection connection)
        {
            dBsercivioRPL = new DBservicioRPL(connection);
        }
        public bool FirtRpl(MirrorResultadoPL item)
        {
            return dBsercivioRPL.FirtDBRpl(item);
        }
        public bool AddRpl(MirrorResultadoPL item)
        {
            return dBsercivioRPL.AddDBRpl(item);
        }
        public bool AddReportePL(MirrorResultadoPL item)
        {
            return dBsercivioRPL.AddDBReportePL(item);
        }
        public int GetLastId()
        {
            return dBsercivioRPL.GetDBLastId();
        }       
        public DataTable GetAllRpl()
        {
            return dBsercivioRPL.GetAllDBRpl();
        }
        public List<MirrorResultadoLab> GetResulListo(int id)
        {
            return dBsercivioRPL.GetDBResulListo(id);
        }
        public List<ResultadoPorCed> GetDBResultPLByCed(string ced)
        {
            return dBsercivioRPL.GetDBResultPLByCed(ced);
        }
    }
}
