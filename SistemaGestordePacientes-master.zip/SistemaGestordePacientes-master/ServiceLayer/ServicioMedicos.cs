﻿using DBservicios;
using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ServiceLayer
{
    public class ServicioMedicos
    {
        private DBservicioMedicos dBservicioMedicos;

        public ServicioMedicos(SqlConnection connection) 
        {
            dBservicioMedicos = new DBservicioMedicos(connection);
        }

        public bool AddMedico(MirrorMedicos item) 
        {
            return dBservicioMedicos.AddDBMedico(item);
        }
        public bool EditMedico(MirrorMedicos item) 
        {
            return dBservicioMedicos.EdiDBtMedico(item);
        }
        public bool DeleteMedico(int id) 
        {
            return dBservicioMedicos.DeleteDBMedico(id);
        }
        public bool AddPhoto(string destination, int id) 
        {
            return dBservicioMedicos.AddDBPhoto(destination, id);
        }
        public int GetLastId() 
        {
            return dBservicioMedicos.GetDBLastId();
        }
        public List<MirrorMedicos> GetMedicoByCed(string ced)
        {
            return dBservicioMedicos.GetDBMedicoByCed(ced);
        }

        public MirrorMedicos GetMedico(int id) 
        {
            return dBservicioMedicos.GetDBMedico(id);
        }
        public DataTable GetAllMedico() 
        {
            return dBservicioMedicos.GetDBAllMedico();
        }

    }
}
