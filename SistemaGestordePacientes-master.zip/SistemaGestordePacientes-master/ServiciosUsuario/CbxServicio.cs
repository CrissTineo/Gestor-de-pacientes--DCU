﻿using DBservicios;
using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace ServiciosUsuario
{
    public class CbxServicio
    {
        private DBCbxServicio dBCbxServicio;
        public CbxServicio(SqlConnection connection) 
        {
            dBCbxServicio = new DBCbxServicio(connection);
        }
        public List<TipoDeUsuario> getTipoUsuario() 
        {
            return dBCbxServicio.GetTipoUsuario();
        }

        public List<Fumador> GetResFumador() 
        {
            return dBCbxServicio.GetDBRespFumador();
        }
    }
}
