﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using DBservicios.MirrorDB;


namespace DBservicios
{
    public class DBCbxServicio
    {
        private SqlConnection _connection;
        public DBCbxServicio(SqlConnection connection)
        {
            _connection = connection;
        }

        public List<TipoDeUsuario> GetTipoUsuario()
        {
            try
            {
                List<TipoDeUsuario> list = new List<TipoDeUsuario>();

                _connection.Open();

                SqlCommand command = new SqlCommand("select * from TipoDeUsuario", _connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    list.Add(new TipoDeUsuario
                    {
                        Id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                        TipoUsuario = reader.IsDBNull(1) ? "" : reader.GetString(1),

                    });
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();
                return list;

            }
            catch (Exception)
            {             
                return null;
            }
        }
        public List<Fumador> GetDBRespFumador()
        {
            try
            {
                List<Fumador> list = new List<Fumador>();

                _connection.Open();

                SqlCommand command = new SqlCommand("select * from Fumador", _connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    list.Add(new Fumador
                    {
                        id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                        Respuesta = reader.IsDBNull(1) ? "" : reader.GetString(1),

                    });
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();
                return list;

            }
            catch (Exception)
            {               
                return null;
            }


        }
    }
}
