﻿using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DBservicios
{
    public class DBservicioRPL
    {
        private SqlConnection _connection;

        public DBservicioRPL(SqlConnection connection) 
        {
            _connection = connection;
        }
        public bool FirtDBRpl(MirrorResultadoPL item)
        {
            SqlCommand command = new SqlCommand("insert into ResultadosDeLaboratorio(idPaciente, idMedico, idCita) Values(@idpaciente, @idmedico, @idcita)", _connection);
            command.Parameters.AddWithValue("@idpaciente", item.idPaciente);
            command.Parameters.AddWithValue("@idmedico", item.idMedico);
            command.Parameters.AddWithValue("@idcita", item.idCita);

            return ExecuterSql(command);
        }
        public bool AddDBRpl(MirrorResultadoPL item)
        {
            SqlCommand command = new SqlCommand("update ResultadosDeLaboratorio set idPruebaDeLab=@idprueba, idEstadoDeResultado=@estado where id =@id", _connection);
            command.Parameters.AddWithValue("@idprueba", item.idPruebaDeLab);
            command.Parameters.AddWithValue("@estado", item.idEstadoDeResultado);
            command.Parameters.AddWithValue("id",item.id);

            return  ExecuterSql(command);
        }
        public bool AddDBReportePL(MirrorResultadoPL item)
        {
            SqlCommand command = new SqlCommand("update ResultadosDeLaboratorio set ResultadoDeLaPrueba=@reporte, idEstadoDeResultado=@estado where id=@id", _connection);
            command.Parameters.AddWithValue("@reporte", item.ResultadoDeLaPrueba);
            command.Parameters.AddWithValue("@estado", item.idEstadoDeResultado);
            command.Parameters.AddWithValue("@id", item.id);

            return ExecuterSql(command);
        }
        public int GetDBLastId()
        {
            try
            {
                int lastId = 0;
                _connection.Open();

                SqlCommand command = new SqlCommand("select max(id) as Id from ResultadosDeLaboratorio", _connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    lastId = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();
                return lastId;
            }
            catch
            {
                return 0;
            }
        }       
        public DataTable GetAllDBRpl() 
        {            
            SqlDataAdapter query = new SqlDataAdapter("select a.id, b.Nombre, b.Apellido, b.Cedula, c.PruebaDeLab, a.ResultadoDeLaPrueba, d.EstadoResultado from ResultadosDeLaboratorio a left join pacientes b on a.idPaciente = b.id left join PruebaDeLaboratorio c on a.idPruebaDeLab = c.id left join EstadoResultado d on a.idEstadoDeResultado = d.id", _connection);
            return LoadData(query);            
        }        
        public List<MirrorResultadoLab> GetDBResulListo(int id)
        {
            try
            {   
                _connection.Open();

                SqlCommand command = new SqlCommand("select b.PruebaDeLab, a.ResultadoDeLaPrueba, c.id  from ResultadosDeLaboratorio a left join PruebaDeLaboratorio b on b.id = a.idPruebaDeLab left join Citas c on a.idCita = c.id where c.id=@id", _connection);
                command.Parameters.AddWithValue("@id",id);

                SqlDataReader reader = command.ExecuteReader();

                List<MirrorResultadoLab> list = new List<MirrorResultadoLab>();

                while (reader.Read())
                {
                    list.Add(new MirrorResultadoLab
                    {
                        PruebaDeLab = reader.IsDBNull(0) ? "" : reader.GetString(0),
                        ResultadoDeLaPrueba = reader.IsDBNull(1) ? "" : reader.GetString(1),
                        idCita = reader.IsDBNull(2) ? 0 : reader.GetInt32(2)
                    }); 
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();
                return list;
            }
            catch(Exception)
            {
                return null;
            }
        }
        public List<ResultadoPorCed> GetDBResultPLByCed(string ced)
        {
            try
            {
                _connection.Open();

                SqlCommand command = new SqlCommand("  select b.Nombre, b.Apellido, b.Cedula, c.PruebaDeLab   from ResultadosDeLaboratorio a left join pacientes b on a.idPaciente = b.id  left join PruebaDeLaboratorio c on a.idPruebaDeLab = c.id where b.Cedula=@ced ", _connection);
                command.Parameters.AddWithValue("@ced", ced);

                SqlDataReader reader = command.ExecuteReader();

                List<ResultadoPorCed> list = new List<ResultadoPorCed>();

                while (reader.Read())
                {
                    list.Add(new ResultadoPorCed
                    {                        
                        Nombre = reader.IsDBNull(0) ? "" : reader.GetString(0),
                        Apellido = reader.IsDBNull(1) ? "" : reader.GetString(1),
                        Cedula = reader.IsDBNull(2) ? "" : reader.GetString(2),
                        PruebalLaboratorio = reader.IsDBNull(3) ? "" : reader.GetString(3),
                       
                    }); ;
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();
                return list;
            }
            catch (Exception)
            {
                return null;
            }
        }
        #region Metodos privados

        private bool ExecuterSql(SqlCommand command) 
        {
            try
            {
                _connection.Open();

                command.ExecuteNonQuery();

                _connection.Close();

                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }
        private DataTable LoadData(SqlDataAdapter query)
        {
            try
            {
                DataTable data = new DataTable();
                _connection.Open();

                query.Fill(data);

                _connection.Close();

                return data;
            }
            catch(Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
