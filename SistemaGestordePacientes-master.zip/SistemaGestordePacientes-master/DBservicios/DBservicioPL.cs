﻿using DBservicios.MirrorDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DBservicios
{
    public class DBservicioPL
    {
        private SqlConnection _connection;
        public DBservicioPL(SqlConnection connection) 
        {
            _connection = connection;
        }
        #region Metodos Publicos
        public bool AddDBPl(MirrorPruebaLab item) 
        {
            SqlCommand command = new SqlCommand("Insert into PruebaDeLaboratorio (PruebaDeLab)Values (@prueba)", _connection);
            command.Parameters.AddWithValue("@prueba", item.PruebaDeLab);

            return ExecuterSQL(command);
        }
        public bool EditDBPl(MirrorPruebaLab item)
        {
            SqlCommand command = new SqlCommand("update PruebaDeLaboratorio set PruebaDeLab=@prueba where id=@id", _connection);
            command.Parameters.AddWithValue("@id", item.id);
            command.Parameters.AddWithValue("@prueba", item.PruebaDeLab);

            return ExecuterSQL(command);            
        }
        public bool DeleteDBPl(int id) 
        {
            SqlCommand command = new SqlCommand("delete PruebaDeLaboratorio where id=@id", _connection);
            command.Parameters.AddWithValue("@id", id);

            return ExecuterSQL(command);
        }
        public MirrorPruebaLab GetDBPl(int id) 
        {
            try
            {
                _connection.Open();

                SqlCommand command = new SqlCommand("select * from PruebaDeLaboratorio where id=@id", _connection);
                command.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = command.ExecuteReader();

                MirrorPruebaLab pl = new MirrorPruebaLab();

                while(reader.Read())
                {
                    pl.id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
                    pl.PruebaDeLab = reader.IsDBNull(1) ? "" : reader.GetString(1);
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();
                return pl;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return null;
            }
        }
        public DataTable GetAllDBPl() 
        {
            SqlDataAdapter query = new SqlDataAdapter("select * from PruebaDeLaboratorio", _connection);
            return LoadData(query);
        }

        #endregion
        #region Metodos Privados

        private bool ExecuterSQL(SqlCommand command)
        {
            try
            {
                _connection.Open();

                 command.ExecuteNonQuery();

                _connection.Close();

                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }
        private DataTable LoadData(SqlDataAdapter query)
        {

            try
            {
                DataTable data = new DataTable();

                _connection.Open();

                query.Fill(data);

                _connection.Close();

                return data;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return null;
            }
        }
        #endregion

    }
}
