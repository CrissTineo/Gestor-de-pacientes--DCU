﻿using DBservicios.MirrorDB;
using System;
using System.Data;
using System.Data.SqlClient;


namespace DBservicios
{
    public class DBservicioUsuarios
    {
        private SqlConnection _connection;
        public DBservicioUsuarios(SqlConnection connection) 
        {
            //trayendo la connection
            _connection = connection;
        }
        public bool AddDBUsuario(MirrorUsuarios item) 
        {
            SqlCommand command = new SqlCommand("insert into Usuarios (Nombre, Apellido, Correo, NombreUsuario, Passw, ConfPassw, idTipoDeUsuario)Values (@nombre, @apellido, @correo, @usuario, @pass, @confpass, @idtipoUsu)", _connection);
            command.Parameters.AddWithValue("@nombre", item.Nombre);
            command.Parameters.AddWithValue("@apellido", item.Apellido);
            command.Parameters.AddWithValue("@correo", item.Correo);
            command.Parameters.AddWithValue("@usuario", item.NombreUsuario);
            command.Parameters.AddWithValue("@pass", item.PassW);
            command.Parameters.AddWithValue("@confpass", item.ConfPassW);
            command.Parameters.AddWithValue("@idtipoUsu", item.idTipoUsuario);             

            return ExecuteSql(command);
        }
        public bool EditDBUsuario(MirrorUsuarios item)
        {
            SqlCommand command = new SqlCommand("update Usuarios set Nombre=@nombre, Apellido=@apellido, Correo=@correo, NombreUsuario=@usuario, Passw=@pass, ConfPassw=@confpass, idTipoDeUsuario=@idtipoUsu where id=@id", _connection);
            command.Parameters.AddWithValue("@nombre", item.Nombre);
            command.Parameters.AddWithValue("@apellido", item.Apellido);
            command.Parameters.AddWithValue("@correo", item.Correo);
            command.Parameters.AddWithValue("@usuario", item.NombreUsuario);
            command.Parameters.AddWithValue("@pass", item.PassW);
            command.Parameters.AddWithValue("@confpass", item.ConfPassW);
            command.Parameters.AddWithValue("@idtipoUsu", item.idTipoUsuario);
            command.Parameters.AddWithValue("@id", item.id);

            return ExecuteSql(command);
        }
        public bool DeleteDBUsuario(int idUsu)
        {
            SqlCommand command = new SqlCommand("delete Usuarios where id=@idUsu ",_connection);
            command.Parameters.AddWithValue("@idUsu", idUsu);

            return ExecuteSql(command);
        }
        public bool LoginDB(string usuario, string pass) 
        {
            try
            {   //variables
                string usu = "";
                string contra = "";
                
                _connection.Open();

                SqlCommand command = new SqlCommand("Select NombreUsuario, Passw from Usuarios where NombreUsuario=@usuario AND Passw=@pass", _connection);
                command.Parameters.AddWithValue("@usuario", usuario );
                command.Parameters.AddWithValue("@pass", pass);

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    usu = reader.IsDBNull(0) ? "" : reader.GetString(0);
                    contra = reader.IsDBNull(1) ? "" : reader.GetString(1);                   
                }
                reader.Close();
                reader.Dispose();
                _connection.Close();

                if (string.IsNullOrEmpty(usu) && string.IsNullOrEmpty(contra))
                {
                    return false;
                }
                else
                {
                    return true;
                }                               
            }
            catch  (Exception e) 
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public MirrorUsuarios GetTipoUsuario(string usuario)
        {
            try
            {
                _connection.Open();

                SqlCommand query = new SqlCommand("select * from Usuarios where NombreUsuario=@usuario", _connection);
                query.Parameters.AddWithValue("@usuario", usuario);             

                SqlDataReader reader = query.ExecuteReader();

                MirrorUsuarios data = new MirrorUsuarios();

                while (reader.Read())
                {
                    data.id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
                    data.Nombre = reader.IsDBNull(1) ? "" : reader.GetString(1);
                    data.Apellido = reader.IsDBNull(2) ? "" : reader.GetString(2);
                    data.Correo = reader.IsDBNull(3) ? "" : reader.GetString(3);
                    data.NombreUsuario = reader.IsDBNull(4) ? "" : reader.GetString(4);
                    data.PassW = reader.IsDBNull(5) ? "" : reader.GetString(5);
                    data.ConfPassW = reader.IsDBNull(6) ? "" : reader.GetString(6);
                    data.idTipoUsuario = reader.IsDBNull(7) ? 0 : reader.GetInt32(7);
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();

                return data;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return null;
            }

        }
        public MirrorUsuarios GetDBUsuario(int idUsu)
        {
            try
            {
                _connection.Open();
               

                SqlCommand query = new SqlCommand("select * from Usuarios where id=@idUsu",_connection);
                query.Parameters.AddWithValue("@idUsu", idUsu);

                SqlDataReader reader =  query.ExecuteReader();

                MirrorUsuarios data = new MirrorUsuarios();

                while (reader.Read()) 
                {
                    data.id = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
                    data.Nombre = reader.IsDBNull(1) ? "" : reader.GetString(1);
                    data.Apellido = reader.IsDBNull(2) ? "" : reader.GetString(2);
                    data.Correo = reader.IsDBNull(3) ? "" : reader.GetString(3);
                    data.NombreUsuario = reader.IsDBNull(4) ? "" : reader.GetString(4);
                    data.PassW = reader.IsDBNull(5) ? "" : reader.GetString(5);
                    data.ConfPassW = reader.IsDBNull(6) ? "" : reader.GetString(6);
                    data.idTipoUsuario = reader.IsDBNull(7) ? 0 : reader.GetInt32(7);
                }
                reader.Close();
                reader.Dispose();

                _connection.Close();

                return data;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return null;
            }            
        }
        public DataTable GetDBAllUsuario()
        {            
                SqlDataAdapter query = new SqlDataAdapter("Select * from Usuarios", _connection);
                //Utilizando Metodo LoadData
                return LoadData(query); 
        }

        #region metodos privados
        private DataTable LoadData(SqlDataAdapter query) 
        {
            try
            {
                DataTable data = new DataTable();

                _connection.Open();

                query.Fill(data);

                _connection.Close();

                return data;
            }
            catch 
            {
                return null;
            }            
        }

        private bool ExecuteSql(SqlCommand query)
        {
            try
            {
                _connection.Open();

                query.ExecuteNonQuery();

                _connection.Close();

                return true;
            }
            catch 
            {
                return false;
            }

        }

        #endregion


    }
}
