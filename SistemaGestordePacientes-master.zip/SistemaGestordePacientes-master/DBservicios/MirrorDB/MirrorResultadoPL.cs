﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBservicios.MirrorDB
{
    public class MirrorResultadoPL
    {
        public int id { get; set; }
        public int idPaciente { get; set; }
        public int idCita { get; set; }
        public int idPruebaDeLab { get; set; }
        public int idMedico { get; set; }
        public string ResultadoDeLaPrueba { get; set; }
        public int idEstadoDeResultado { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Cedula { get; set; }        
        public string PruebaDeLaboratorio { get; set; }
        public string EstadoResultado { get; set; }

    }
}
