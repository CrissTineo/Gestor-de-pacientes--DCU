﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBservicios.MirrorDB
{
    public class MirrorResultadoLab
    {     
        public int idCita { get; set; }      
        public string ResultadoDeLaPrueba { get; set; }       
        public string PruebaDeLab { get; set; }
    }
}
