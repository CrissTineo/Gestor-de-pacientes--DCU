﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBservicios.MirrorDB
{
    public class Fumador
    {
        public int id { get; set; }
        public string Respuesta { get; set; }

    }
}
