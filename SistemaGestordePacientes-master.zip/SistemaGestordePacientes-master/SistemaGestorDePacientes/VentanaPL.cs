﻿using DBservicios.MirrorDB;
using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class VentanaPL : Form
    {
        private ServicioRPL servRPL;
        private ServicioPl servPL;
        private ServicioCitas servCitas;
          
        public VentanaPL()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConeccition = new SqlConnection(connectionStrings);

            servRPL = new ServicioRPL(sqlConeccition);
            servPL = new ServicioPl(sqlConeccition);
            servCitas = new ServicioCitas(sqlConeccition);
        }
        #region Eventos
        private void VentanaPL_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void VentanaPL_FormClosing(object sender, FormClosingEventArgs e)
        {
            MantCita mCita = new MantCita();
            mCita.Show();            
        }
        private void DgvPL_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = 0;
            index = Convert.ToInt32(DgvPL.Rows[e.RowIndex].Cells[0].Value.ToString());
            if (index > 0)
            {
                BtnRealizar.Visible = true;
            }
        }
        private void BtnRealizar_Click(object sender, EventArgs e)
        {
            AddPruebasDeLab();
        }
        private void BtnDeseleccionar_Click(object sender, EventArgs e)
        {
            Deseleccionar();
        }
        private void Btncancelar_Click(object sender, EventArgs e)
        {            
            this.Close();
        }
        #endregion

        #region Metodos
        private void LoadData()
        {           
            DgvPL.DataSource = servPL.GetAllPl();
            DgvPL.ClearSelection();
        }
             
        private void AddPruebasDeLab()
        {
            MirrorResultadoPL Rpl = new MirrorResultadoPL();
            MirrorCitas mCita = new MirrorCitas();
            
            foreach(DataGridViewRow dwv in DgvPL.SelectedRows)//Obtengo el valor de todos los Rows Seleccionado
            {
                CrearConsultar();//Crea un RPL por cada Prueba seleccionada
                Rpl.idPruebaDeLab = Convert.ToInt32(dwv.Cells[0].Value);
                Rpl.idEstadoDeResultado = 1;
                Rpl.id = servRPL.GetLastId();                
                bool result = servRPL.AddRpl(Rpl);
                if (result == true)
                {
                    MessageBox.Show($"Prueba {Rpl.idPruebaDeLab} seleccionada con exito", "Notificación");                    
                }                
            }
            mCita.id = CroosIndex.indice;
            mCita.idEstadoDeLaCita = 2;
            servCitas.UpdateEstadoCita(mCita);
            this.Close();
        }
        private void Deseleccionar()
        {
            DgvPL.ClearSelection();
        }
        private void CrearConsultar()//Creo un Resultado
        {
            MirrorResultadoPL Rpl = new MirrorResultadoPL();
            
            Rpl.idPaciente = servCitas.GetCita(CroosIndex.indice).idPaciente;
            Rpl.idMedico = servCitas.GetCita(CroosIndex.indice).idMedico;
            Rpl.idCita = servCitas.GetCita(CroosIndex.indice).id;

            servRPL.FirtRpl(Rpl);
        }

        #endregion


    }
}
