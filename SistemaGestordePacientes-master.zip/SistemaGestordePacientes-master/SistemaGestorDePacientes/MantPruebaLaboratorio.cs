﻿using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class MantPruebaLaboratorio : Form
    {
        FormMain main = new FormMain();
        ServicioPl servicioPl;
        Login login;
        public MantPruebaLaboratorio()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnecion = new SqlConnection(connectionStrings);

            servicioPl = new ServicioPl(sqlConnecion);
            login = new Login();
        }
        #region Eventos     
        private void volverAtrasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            main.Show();
        }        
        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void BtnAgregarPrueba_Click(object sender, EventArgs e)
        {
            Add();
        }
        private void BtnEditarPrueba_Click(object sender, EventArgs e)
        {
            Editar();
        }
        private void BtnDeseleccionar_Click(object sender, EventArgs e)
        {
            DgvPruebasLab.ClearSelection();
            CroosIndex.indice = 0;
        }
        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            Delete();
        }
        private void DgvPruebasLab_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            CroosIndex.indice = Convert.ToInt32(DgvPruebasLab.Rows[e.RowIndex].Cells[0].Value.ToString());
        }
        private void MantPruebaLaboratorio_Load(object sender, EventArgs e)
        {            
            ListarPl();
        }
        #endregion

        #region Metodos
        private void Delete() 
        {
            if (CroosIndex.indice>0) 
            {
                DialogResult resp = MessageBox.Show("Seguro que desea eliminar esta prueba", "Aviso", MessageBoxButtons.YesNo);

                if (resp == DialogResult.Yes)
                {
                    servicioPl.DeletePl(CroosIndex.indice);
                    MessageBox.Show("Eliminado Con Exito", "Notificación");
                    CroosIndex.indice = 0;
                    ListarPl();
                }
                else
                {
                    MessageBox.Show("Eliminado Cancelado", "Aviso");
                }
            }
            else 
            {
                MessageBox.Show("Debe seleccionar una prueba");
            }
        }
        private void ListarPl() 
        {
            DgvPruebasLab.DataSource = servicioPl.GetAllPl();
            DgvPruebasLab.ClearSelection();
            CroosIndex.indice = 0;
        }
        private void Add() 
        {
            if (CroosIndex.indice == 0)
            {
                FormDatosPruebaDeLab formDatosPrueba = new FormDatosPruebaDeLab();
                formDatosPrueba.Show();
                this.Hide();
            }
            else 
            {
                MessageBox.Show("Ha seleccionado una prueba, haga clic en el boton editar o primero deseleccione para agregar", "Aviso");
            }
        }
        private void Editar()
        {
            if (CroosIndex.indice > 0)
            {
                FormDatosPruebaDeLab formDatosPrueba = new FormDatosPruebaDeLab();
                formDatosPrueba.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Debe selecionar una prueba para editar", "Notificación");
            }
        }
        #endregion

       
    }
}
