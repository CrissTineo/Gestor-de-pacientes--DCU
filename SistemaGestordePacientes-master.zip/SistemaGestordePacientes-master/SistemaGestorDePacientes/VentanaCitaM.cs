﻿using DBservicios.MirrorDB;
using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class VentanaCitaM : Form
    {
        MantCita mantCita;
        VentanaCausaCita vCausa;
        ServicioMedicos servMedicos;
        ServicioCitas servCitas;
        public VentanaCitaM()
        {
            InitializeComponent();
            string ConnectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlconnection = new SqlConnection(ConnectionStrings);

            mantCita = new MantCita();
            vCausa = new VentanaCausaCita();
            servMedicos = new ServicioMedicos(sqlconnection);
            servCitas = new ServicioCitas(sqlconnection);
        }
        #region Eventos
        private void BtnSiguiente_Click(object sender, EventArgs e)
        {
            AddMedico();
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            CancelarBtn();
        }
        private void VentanaCitaM_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void DgvVentanaM_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            CroosIndex.indice = Convert.ToInt32(DgvVentanaM.Rows[e.RowIndex].Cells[0].Value.ToString());
            BtnSiguiente.Visible = true;
        }
        private void BtnDeseleccion_Click(object sender, EventArgs e)
        {
            Deseleccion();
        }
        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            Buscar();
        }
        #endregion

        #region Metodos
        private void LoadData()
        {
            if (string.IsNullOrEmpty(TxtCedula.Text))
            {
                DgvVentanaM.DataSource = servMedicos.GetAllMedico();
                DgvVentanaM.ClearSelection();
            }
            else
            {
                DgvVentanaM.DataSource = servMedicos.GetMedicoByCed(TxtCedula.Text);
                DgvVentanaM.ClearSelection();
            }
        }
        private void AddMedico()
        {
            if (CroosIndex.indice > 0)
            {
                MirrorCitas mCitas = new MirrorCitas();
                mCitas.id = servCitas.GetlastId();
                mCitas.idMedico = CroosIndex.indice;
                
                bool result = servCitas.AddCitaMedico(mCitas);
                if (result == true)
                {
                    MessageBox.Show("Medico añadido");
                    CroosIndex.indice = 0;
                    vCausa.Show();
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Debe seleccionar un medico");
            }
        }
        private void CancelarBtn()
        {
            int lastId = servCitas.GetlastId();
            CroosIndex.indice = 0;
            servCitas.DeleteCita(lastId);//Elimino la cita creada en la ventana anterior            
            mantCita.Show();
            this.Close();
        }
        private void Deseleccion()
        {
            DgvVentanaM.ClearSelection();
            BtnSiguiente.Visible = false;
            CroosIndex.indice = 0;
        }
        private void Buscar()
        {
            if (string.IsNullOrEmpty(TxtCedula.Text))
            {
                MessageBox.Show("Debe ingresar la cedula", "Aviso");
            }
            else
            {
                LoadData();
            }
        }
        #endregion

       
    }
}
