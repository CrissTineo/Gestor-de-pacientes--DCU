﻿
namespace SistemaGestorDePacientes
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MsFormMain = new System.Windows.Forms.ToolStripMenuItem();
            this.cerrarSesionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PbPerfil = new System.Windows.Forms.PictureBox();
            this.BtnUsuarios = new System.Windows.Forms.Button();
            this.BtnMedicos = new System.Windows.Forms.Button();
            this.BtnMantPruebaDeL = new System.Windows.Forms.Button();
            this.BtnMantPacientes = new System.Windows.Forms.Button();
            this.BtnMantCitas = new System.Windows.Forms.Button();
            this.BtnMantRPL = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbPerfil)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.BackgroundImage = global::SistemaGestorDePacientes.Properties.Resources.abstract_geometric_hexagons_shape_medicine_science_concept_background_medical_ico;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.PbPerfil, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.BtnUsuarios, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnMedicos, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnMantPruebaDeL, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnMantPacientes, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.BtnMantCitas, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.BtnMantRPL, 2, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.55556F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.444444F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.78967F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.31365F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(982, 542);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.SetColumnSpan(this.menuStrip1, 3);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MsFormMain});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(982, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MsFormMain
            // 
            this.MsFormMain.BackColor = System.Drawing.Color.PaleTurquoise;
            this.MsFormMain.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cerrarSesionToolStripMenuItem});
            this.MsFormMain.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MsFormMain.ForeColor = System.Drawing.SystemColors.Highlight;
            this.MsFormMain.Name = "MsFormMain";
            this.MsFormMain.Size = new System.Drawing.Size(84, 23);
            this.MsFormMain.Text = "Opciones";
            // 
            // cerrarSesionToolStripMenuItem
            // 
            this.cerrarSesionToolStripMenuItem.BackColor = System.Drawing.Color.Ivory;
            this.cerrarSesionToolStripMenuItem.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cerrarSesionToolStripMenuItem.Name = "cerrarSesionToolStripMenuItem";
            this.cerrarSesionToolStripMenuItem.Size = new System.Drawing.Size(180, 24);
            this.cerrarSesionToolStripMenuItem.Text = "Cerrar Sesion";
            this.cerrarSesionToolStripMenuItem.Click += new System.EventHandler(this.cerrarSesionToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::SistemaGestorDePacientes.Properties.Resources.Artboard_2;
            this.pictureBox1.Location = new System.Drawing.Point(330, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(321, 237);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // PbPerfil
            // 
            this.PbPerfil.BackColor = System.Drawing.Color.Transparent;
            this.PbPerfil.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PbPerfil.Location = new System.Drawing.Point(3, 51);
            this.PbPerfil.Name = "PbPerfil";
            this.PbPerfil.Size = new System.Drawing.Size(321, 237);
            this.PbPerfil.TabIndex = 2;
            this.PbPerfil.TabStop = false;
            // 
            // BtnUsuarios
            // 
            this.BtnUsuarios.AutoSize = true;
            this.BtnUsuarios.BackColor = System.Drawing.Color.SteelBlue;
            this.BtnUsuarios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnUsuarios.FlatAppearance.BorderColor = System.Drawing.Color.SpringGreen;
            this.BtnUsuarios.FlatAppearance.BorderSize = 2;
            this.BtnUsuarios.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnUsuarios.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnUsuarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnUsuarios.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnUsuarios.ForeColor = System.Drawing.Color.AliceBlue;
            this.BtnUsuarios.Location = new System.Drawing.Point(3, 311);
            this.BtnUsuarios.Name = "BtnUsuarios";
            this.BtnUsuarios.Size = new System.Drawing.Size(321, 115);
            this.BtnUsuarios.TabIndex = 1;
            this.BtnUsuarios.Text = "Usuarios";
            this.BtnUsuarios.UseVisualStyleBackColor = false;
            this.BtnUsuarios.Visible = false;
            this.BtnUsuarios.Click += new System.EventHandler(this.BtnUsuarios_Click);
            // 
            // BtnMedicos
            // 
            this.BtnMedicos.AutoSize = true;
            this.BtnMedicos.BackColor = System.Drawing.Color.SteelBlue;
            this.BtnMedicos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnMedicos.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.BtnMedicos.FlatAppearance.BorderSize = 2;
            this.BtnMedicos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnMedicos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnMedicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMedicos.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnMedicos.ForeColor = System.Drawing.Color.AliceBlue;
            this.BtnMedicos.Location = new System.Drawing.Point(330, 311);
            this.BtnMedicos.Name = "BtnMedicos";
            this.BtnMedicos.Size = new System.Drawing.Size(321, 115);
            this.BtnMedicos.TabIndex = 2;
            this.BtnMedicos.Text = "Medicos";
            this.BtnMedicos.UseVisualStyleBackColor = false;
            this.BtnMedicos.Visible = false;
            this.BtnMedicos.Click += new System.EventHandler(this.BtnMedicos_Click);
            // 
            // BtnMantPruebaDeL
            // 
            this.BtnMantPruebaDeL.AutoSize = true;
            this.BtnMantPruebaDeL.BackColor = System.Drawing.Color.SteelBlue;
            this.BtnMantPruebaDeL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnMantPruebaDeL.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
            this.BtnMantPruebaDeL.FlatAppearance.BorderSize = 2;
            this.BtnMantPruebaDeL.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnMantPruebaDeL.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnMantPruebaDeL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMantPruebaDeL.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnMantPruebaDeL.ForeColor = System.Drawing.Color.AliceBlue;
            this.BtnMantPruebaDeL.Location = new System.Drawing.Point(657, 311);
            this.BtnMantPruebaDeL.Name = "BtnMantPruebaDeL";
            this.BtnMantPruebaDeL.Size = new System.Drawing.Size(322, 115);
            this.BtnMantPruebaDeL.TabIndex = 3;
            this.BtnMantPruebaDeL.Text = "Pruebas de Laboratorio.";
            this.BtnMantPruebaDeL.UseVisualStyleBackColor = false;
            this.BtnMantPruebaDeL.Visible = false;
            this.BtnMantPruebaDeL.Click += new System.EventHandler(this.BtnMantPruebaDeL_Click);
            // 
            // BtnMantPacientes
            // 
            this.BtnMantPacientes.AutoSize = true;
            this.BtnMantPacientes.BackColor = System.Drawing.Color.SteelBlue;
            this.BtnMantPacientes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnMantPacientes.FlatAppearance.BorderColor = System.Drawing.Color.Lime;
            this.BtnMantPacientes.FlatAppearance.BorderSize = 2;
            this.BtnMantPacientes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnMantPacientes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnMantPacientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMantPacientes.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnMantPacientes.ForeColor = System.Drawing.Color.AliceBlue;
            this.BtnMantPacientes.Location = new System.Drawing.Point(3, 432);
            this.BtnMantPacientes.Name = "BtnMantPacientes";
            this.BtnMantPacientes.Size = new System.Drawing.Size(321, 107);
            this.BtnMantPacientes.TabIndex = 4;
            this.BtnMantPacientes.Text = "Pacientes";
            this.BtnMantPacientes.UseVisualStyleBackColor = false;
            this.BtnMantPacientes.Visible = false;
            this.BtnMantPacientes.Click += new System.EventHandler(this.BtnMantPacientes_Click);
            // 
            // BtnMantCitas
            // 
            this.BtnMantCitas.AutoSize = true;
            this.BtnMantCitas.BackColor = System.Drawing.Color.SteelBlue;
            this.BtnMantCitas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnMantCitas.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.BtnMantCitas.FlatAppearance.BorderSize = 2;
            this.BtnMantCitas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnMantCitas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnMantCitas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMantCitas.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnMantCitas.ForeColor = System.Drawing.Color.AliceBlue;
            this.BtnMantCitas.Location = new System.Drawing.Point(330, 432);
            this.BtnMantCitas.Name = "BtnMantCitas";
            this.BtnMantCitas.Size = new System.Drawing.Size(321, 107);
            this.BtnMantCitas.TabIndex = 5;
            this.BtnMantCitas.Text = "Citas";
            this.BtnMantCitas.UseVisualStyleBackColor = false;
            this.BtnMantCitas.Visible = false;
            this.BtnMantCitas.Click += new System.EventHandler(this.BtnMantCitas_Click);
            // 
            // BtnMantRPL
            // 
            this.BtnMantRPL.AutoSize = true;
            this.BtnMantRPL.BackColor = System.Drawing.Color.SteelBlue;
            this.BtnMantRPL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnMantRPL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BtnMantRPL.FlatAppearance.BorderSize = 2;
            this.BtnMantRPL.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnMantRPL.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnMantRPL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMantRPL.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnMantRPL.ForeColor = System.Drawing.Color.AliceBlue;
            this.BtnMantRPL.Location = new System.Drawing.Point(657, 432);
            this.BtnMantRPL.Name = "BtnMantRPL";
            this.BtnMantRPL.Size = new System.Drawing.Size(322, 107);
            this.BtnMantRPL.TabIndex = 6;
            this.BtnMantRPL.Text = "Resultados Prueba de Lab.";
            this.BtnMantRPL.UseVisualStyleBackColor = false;
            this.BtnMantRPL.Visible = false;
            this.BtnMantRPL.Click += new System.EventHandler(this.BtnMantRPL_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(982, 542);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormMain";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbPerfil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MsFormMain;
        private System.Windows.Forms.ToolStripMenuItem cerrarSesionToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox PbPerfil;
        private System.Windows.Forms.Button BtnUsuarios;
        private System.Windows.Forms.Button BtnMedicos;
        private System.Windows.Forms.Button BtnMantPruebaDeL;
        private System.Windows.Forms.Button BtnMantPacientes;
        private System.Windows.Forms.Button BtnMantCitas;
        private System.Windows.Forms.Button BtnMantRPL;
    }
}