﻿using DBservicios.MirrorDB;
using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class FormDatosMedico : Form
    {
        private string _FileName = "";//Variable para guardar el nombre de la foto

        private ServicioMedicos serMedicos;
        public FormDatosMedico()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionStrings);

            serMedicos = new ServicioMedicos(sqlConnection);
        }
        #region Eventos
        private void BtnFoto_Click(object sender, EventArgs e)
        {
            Addphoto();
        }
        private void FormDatosMedico_FormClosing(object sender, FormClosingEventArgs e)
        {
            MantMedicos mantMedicos = new MantMedicos();
            mantMedicos.Show();
        }
        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            AddMedico();
        }
        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void FormDatosMedico_Load(object sender, EventArgs e)
        {
            EditarMedico();//Cargo los Txt si el indice tiene valor
        }

        #endregion
        #region Metodos
        private void AddMedico() 
        {
            if (CroosIndex.indice==0) 
            {
                MirrorMedicos medico = new MirrorMedicos();

                if (string.IsNullOrEmpty(TxtNombre.Text))
                {
                    MessageBox.Show("Debe ingresar un nombre", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtApellido.Text))
                {
                    MessageBox.Show("Debe ingresar un apellido", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtEmail.Text))
                {
                    MessageBox.Show("Debe Ingresar un correo electronico", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtTelefono.Text))
                {
                    MessageBox.Show("Debe ingresar un numero telefonico", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtCedula.Text))
                {
                    MessageBox.Show("Debe ingresar la cedula", "Notificación");
                }
                else 
                {
                    medico.Nombre = TxtNombre.Text;
                    medico.Apellido = TxtApellido.Text;
                    medico.Correo = TxtEmail.Text;
                    medico.Telefono = TxtTelefono.Text;
                    medico.Cedula = TxtCedula.Text;

                    bool result = serMedicos.AddMedico(medico);

                    if (result == true)
                    {                       
                        MessageBox.Show("Medico agregado con exito", "Notificación");       
                        
                        SavePhoto(serMedicos.GetLastId());// Le paso el id al metodo save foto luego de que crea el Medico
                        _FileName = "";
                        this.Close();                       
                    }
                    else {
                        MessageBox.Show("No se pudo agregar el medico", "Aviso");
                    
                    }
                }              

            }
            else if (CroosIndex.indice>0)
            {
                MirrorMedicos medico = new MirrorMedicos();

                if (string.IsNullOrEmpty(TxtNombre.Text))
                {
                    MessageBox.Show("Debe ingresar un nombre", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtApellido.Text))
                {
                    MessageBox.Show("Debe ingresar un apellido", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtEmail.Text))
                {
                    MessageBox.Show("Debe Ingresar un correo electronico", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtTelefono.Text))
                {
                    MessageBox.Show("Debe ingresar un numero telefonico", "Notificación");
                }
                else if (string.IsNullOrEmpty(TxtCedula.Text))
                {
                    MessageBox.Show("Debe ingresar la cedula", "Notificación");
                }
                else
                {
                    medico.Nombre = TxtNombre.Text;
                    medico.Apellido = TxtApellido.Text;
                    medico.Correo = TxtEmail.Text;
                    medico.Telefono = TxtTelefono.Text;
                    medico.Cedula = TxtCedula.Text;
                    medico.id = CroosIndex.indice;
                    
                    bool result = serMedicos.EditMedico(medico);

                    if (result == true)
                    {
                        if (_FileName == "")
                        {
                            MessageBox.Show("Medico editado con exito", "Notificación");
                            CroosIndex.indice = 0;
                            this.Close();                           
                        }
                        else 
                        {
                            MessageBox.Show("Medico editado con exito", "Notificación");
                            SavePhoto(CroosIndex.indice);
                            _FileName = "";
                            CroosIndex.indice = 0;
                            this.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("No se pudo editar el Medico", "Aviso");
                    }
                }
            }

        }
        private void EditarMedico() //Lo llamo cuando se carga este formulario
        {
            MirrorMedicos medico = serMedicos.GetMedico(CroosIndex.indice);
            TxtNombre.Text = medico.Nombre;
            TxtApellido.Text = medico.Apellido;
            TxtEmail.Text = medico.Correo;
            TxtTelefono.Text = medico.Telefono;
            TxtCedula.Text = medico.Cedula;
        }

        private void Addphoto() 
        {
            DialogResult result = PictureDialogo.ShowDialog();
            if (result == DialogResult.OK ) 
            {
                string fileName = PictureDialogo.FileName;
                _FileName = fileName;
            }
        }
        private void SavePhoto(int id) 
        {            
            EDirectory eDirectory = new EDirectory();

            string directory = @"Images\Medicos\" + id + "\\";

            eDirectory.CreateDirectory(directory);

            string[] filenameSplit = _FileName.Split("\\");

            string file = filenameSplit[filenameSplit.Length -1];

            string destination = directory + file;

            File.Copy(_FileName, destination, true);

            bool resultado = serMedicos.AddPhoto(destination, id);

            if (resultado == false)
            {
                MessageBox.Show("No se pudo agregar la foto");
            }
           
            
        }

        #endregion

        
    }
}
