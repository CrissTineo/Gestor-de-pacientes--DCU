﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SistemaGestorDePacientes.CrossClass
{
     public static class IdTipoUsuario
    {       
            static public int IdTipoUsu;        
    }
}
