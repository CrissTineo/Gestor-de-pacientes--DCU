﻿using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class MantPacientes : Form
    {
        ServicioPacientes servPacientes;
        FormMain main;
        public MantPacientes()
        {
            InitializeComponent();

            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionStrings);

            servPacientes = new ServicioPacientes(sqlConnection);
            main = new FormMain();
        }
        #region Eventos
        private void MantPacientes_Load(object sender, EventArgs e)
        {
            LoadDgv();
        }
        private void BtnCrearPaciente_Click(object sender, EventArgs e)
        {
            AddPaciente();
        }
        private void BtnDeseleccionar_Click(object sender, EventArgs e)
        {
            Deseleccionar();
        }
        private void BtnEliminarPac_Click(object sender, EventArgs e)
        {
            Delete();
        }
        private void DgvPacientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            CroosIndex.indice = Convert.ToInt32(DgvPacientes.Rows[e.RowIndex].Cells[0].Value.ToString());            
            PicBox.ImageLocation = servPacientes.GetPaciente(CroosIndex.indice).ProfilePhoto;
        }
        private void BtnEditarPaciente_Click(object sender, EventArgs e)
        {
            Editar();
        }
        private void volverAtrasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            main.Show();
            this.Close();
        }
        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        #endregion
        #region Metodos
        private void AddPaciente() 
        {
            if (CroosIndex.indice==0) 
            {
                FormDatosPacientes fPacientes = new FormDatosPacientes();
                fPacientes.Show();
                this.Hide();
            }
            else 
            {
                MessageBox.Show("Ha seleccionado un paciente, haga clic en el boton editar o primero deseleccione para agregar", "Aviso");
            }
        }
        private void Editar() 
        {
            if (CroosIndex.indice >0)
            {
                FormDatosPacientes fPacientes = new FormDatosPacientes();
                fPacientes.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Debe seleccionar un paciente");
            }
        }        
        private void Delete()
        {
            if (CroosIndex.indice > 0)
            {
                DialogResult resp = MessageBox.Show("Seguro que desea eliminar este paciente?", "Aviso", MessageBoxButtons.YesNo);
                if (resp == DialogResult.Yes)
                {
                    bool resultado = servPacientes.DeletePaciente(CroosIndex.indice);
                    if (resultado == true)
                    {
                        MessageBox.Show("Paciente eliminado con exito");
                        LoadDgv();
                        Deseleccionar();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar");
                    }
                }
            }
        }
        private void Deseleccionar() 
        {
            DgvPacientes.ClearSelection();
            CroosIndex.indice = 0;
            PicBox.ImageLocation = "";
        }
        private void LoadDgv()
        {
            DgvPacientes.DataSource= servPacientes.GetAllPacientes();
            DgvPacientes.ClearSelection();
            CroosIndex.indice = 0;
        }
        #endregion

        
    }
}
