﻿using DBservicios.MirrorDB;
using ServiceLayer;
using ServiciosUsuario;
using SistemaGestorDePacientes.CrossClass;
using SistemaGestorDePacientes.CustomItemCbx;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class FormDatosPacientes : Form
    {
        ServicioPacientes serPacientes;
        
        MantPacientes mantP;
        CbxServicio cbxServ;
        private string _FileName = "";
        public FormDatosPacientes()
        {
            InitializeComponent();

            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection sqlConnection = new SqlConnection(connectionStrings);

            cbxServ = new CbxServicio(sqlConnection);
            serPacientes = new ServicioPacientes(sqlConnection);           
            mantP = new MantPacientes();
            
        }
        #region Eventos
        private void FormDatosPacientes_FormClosing(object sender, FormClosingEventArgs e)
        {
            mantP.Show();
        }
        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void BtnSubirFoto_Click(object sender, EventArgs e)
        {
            AddPhoto(); 
        }
        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            Agregar();
        }
        private void FormDatosPacientes_Load(object sender, EventArgs e)
        {
            LoadCbx();
            RellenarEdit();
        }
        #endregion

        #region Metodos
        private void LoadCbx()
        {

            CbxFumador opcPorDefecto = new CbxFumador
            {
                Text = "Respuesta",
                Value = null
            };
            CbxF.Items.Add(opcPorDefecto);

            List<Fumador> list = cbxServ.GetResFumador();

            foreach (Fumador item in list)
            {
                CbxFumador cbx = new CbxFumador
                {
                    Text = item.Respuesta,
                    Value = item.id

                };
                CbxF.Items.Add(cbx);
            }
            CbxF.SelectedItem = opcPorDefecto;

        }
        private void Agregar()
        {
            if (CroosIndex.indice == 0)
            {
                MirrorPacientes paciente = new MirrorPacientes();
                CbxFumador cbx = CbxF.SelectedItem as CbxFumador;

                if (string.IsNullOrEmpty(TxtNombre.Text))
                {
                    MessageBox.Show("Debe ingresar un nombre");
                }
                else if (string.IsNullOrEmpty(TxtApellido.Text))
                {
                    MessageBox.Show("Debe ingresar un apellido");
                }
                else if (string.IsNullOrEmpty(MaskTxtTel.Text))
                {
                    MessageBox.Show("Debe ingresar el telefono");
                }
                else if (string.IsNullOrEmpty(TxtDireccion.Text))
                {
                    MessageBox.Show("Debe ingresar la dirección");
                }
                else if (string.IsNullOrEmpty(TxtCedula.Text))
                {
                    MessageBox.Show("Debe ingresar la cedula");
                }
                else if (string.IsNullOrEmpty(MaskTxtFecha.Text))
                {
                    MessageBox.Show("Debe ingresar la fecha de nacimiento");
                }
                else if (cbx.Value == null)
                {
                    MessageBox.Show("Seleccione la respuesta de fumador");
                }
                else if (string.IsNullOrEmpty(TxtAlergias.Text)) 
                {
                    MessageBox.Show("Responder, Es alergico a algo?");
                }
                else 
                {
                    paciente.Nombre = TxtNombre.Text;
                    paciente.Apellido = TxtApellido.Text;
                    paciente.Telefono = MaskTxtTel.Text;
                    paciente.Direccion = TxtDireccion.Text;
                    paciente.Cedula = TxtCedula.Text;
                    paciente.FechaDeNacimiento = MaskTxtFecha.Text;
                    paciente.Fumador = Convert.ToInt32(cbx.Value);
                    paciente.Alergia = TxtAlergias.Text;

                    bool result = serPacientes.AddPaciente(paciente);

                    if (result == true) 
                    {
                        MessageBox.Show("Paciente agregado con exito", "Notificación");

                        SavePhoto(serPacientes.GetLastId());                        
                        this.Close();
                        _FileName = "";
                    }
                    else 
                    {
                        MessageBox.Show("No se pudo agregar el paciente", "Aviso");
                    }
                }
            }
            else if (CroosIndex.indice > 0)
            {
                MirrorPacientes paciente = new MirrorPacientes();
                CbxFumador cbx = CbxF.SelectedItem as CbxFumador;

                if (string.IsNullOrEmpty(TxtNombre.Text))
                {
                    MessageBox.Show("Debe ingresar un nombre");
                }
                else if (string.IsNullOrEmpty(TxtApellido.Text))
                {
                    MessageBox.Show("Debe ingresar un apellido");
                }
                else if (string.IsNullOrEmpty(MaskTxtTel.Text))
                {
                    MessageBox.Show("Debe ingresar el telefono");
                }
                else if (string.IsNullOrEmpty(TxtDireccion.Text))
                {
                    MessageBox.Show("Debe ingresar la dirección");
                }
                else if (string.IsNullOrEmpty(TxtCedula.Text))
                {
                    MessageBox.Show("Debe ingresar la cedula");
                }
                else if (string.IsNullOrEmpty(MaskTxtFecha.Text))
                {
                    MessageBox.Show("Debe ingresar la fecha de nacimiento");
                }
                else if (cbx.Value == null)
                {
                    MessageBox.Show("Seleccione la respuesta de fumador");
                }
                else if (string.IsNullOrEmpty(TxtAlergias.Text))
                {
                    MessageBox.Show("Responder, Es alergico a algo?");
                }
                else
                {
                    paciente.Nombre = TxtNombre.Text;
                    paciente.Apellido = TxtApellido.Text;
                    paciente.Telefono = MaskTxtTel.Text;
                    paciente.Direccion = TxtDireccion.Text;
                    paciente.Cedula = TxtCedula.Text;
                    paciente.FechaDeNacimiento = MaskTxtFecha.Text;
                    paciente.Fumador = Convert.ToInt32(cbx.Value);
                    paciente.Alergia = TxtAlergias.Text;
                    paciente.id = CroosIndex.indice;
                    
                    bool result = serPacientes.Editpaciente(paciente);

                    if (result == true)
                    {
                        if (_FileName == "") 
                        {
                            MessageBox.Show("Paciente editado con exito", "Notificación");                           
                            CroosIndex.indice = 0;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Paciente editado con exito", "Notificación");
                            SavePhoto(CroosIndex.indice);
                            _FileName = "";
                            CroosIndex.indice = 0;
                            this.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("No se pudo editar el paciente", "Aviso");
                    }
                }
            }
        }
        private void AddPhoto() 
        {
            DialogResult resp = PicDialogo.ShowDialog();
            if (resp == DialogResult.OK) 
            {
                string fileName = PicDialogo.FileName;
                _FileName = fileName;
            }
        }

        private void SavePhoto(int id) 
        {
            EDirectory eDirectory = new EDirectory();

            string directory = @"Images\Pacientes\" + id + "\\";

            eDirectory.CreateDirectory(directory);

            string[] filenameSplit = _FileName.Split("\\");

            string file = filenameSplit[filenameSplit.Length - 1];

            string destination = directory + file;

            File.Copy(_FileName, destination, true);

            bool resultado = serPacientes.AddPhoto(destination, id);

            if (resultado == false)
            {
                MessageBox.Show("No se pudo agregar la foto");
            }
        }
        private void RellenarEdit() 
        {
            MirrorPacientes paciente =  serPacientes.GetPaciente(CroosIndex.indice);

            TxtNombre.Text = paciente.Nombre;
            TxtApellido.Text = paciente.Apellido;
            MaskTxtTel.Text = paciente.Telefono;
            TxtDireccion.Text = paciente.Direccion;
            TxtCedula.Text = paciente.Cedula;
            MaskTxtFecha.Text = paciente.FechaDeNacimiento;
            CbxF.SelectedItem = paciente.Fumador;
            TxtAlergias.Text = paciente.Alergia;
        }
        #endregion      
    }
}
