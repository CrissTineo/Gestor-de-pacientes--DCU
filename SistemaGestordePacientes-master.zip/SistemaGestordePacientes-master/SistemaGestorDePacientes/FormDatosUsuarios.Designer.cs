﻿
namespace SistemaGestorDePacientes
{
    partial class FormDatosUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LblNombre = new System.Windows.Forms.Label();
            this.LblApellido = new System.Windows.Forms.Label();
            this.LblCorreoElectronico = new System.Windows.Forms.Label();
            this.LblNombreUsuario = new System.Windows.Forms.Label();
            this.LblContraseña = new System.Windows.Forms.Label();
            this.LblconfContraseña = new System.Windows.Forms.Label();
            this.LblTipoUsuario = new System.Windows.Forms.Label();
            this.TxtNombre = new System.Windows.Forms.TextBox();
            this.TxtApellido = new System.Windows.Forms.TextBox();
            this.TxtEmail = new System.Windows.Forms.TextBox();
            this.TxtUsuario = new System.Windows.Forms.TextBox();
            this.TxtContraseña = new System.Windows.Forms.TextBox();
            this.TxtConfContraseña = new System.Windows.Forms.TextBox();
            this.CbxTipoUsuario = new System.Windows.Forms.ComboBox();
            this.BtnAceptar = new System.Windows.Forms.Button();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.BackgroundImage = global::SistemaGestorDePacientes.Properties.Resources.abstract_geometric_hexagons_shape_medicine_science_concept_background_medical_ico;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.LblNombre, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.LblApellido, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.LblCorreoElectronico, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.LblNombreUsuario, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.LblContraseña, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.LblconfContraseña, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.LblTipoUsuario, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.TxtNombre, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.TxtApellido, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.TxtEmail, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.TxtUsuario, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.TxtContraseña, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.TxtConfContraseña, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.CbxTipoUsuario, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.BtnAceptar, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.BtnCancelar, 1, 10);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 12;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(878, 610);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::SistemaGestorDePacientes.Properties.Resources.Artboard_2;
            this.pictureBox1.Location = new System.Drawing.Point(295, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.tableLayoutPanel1.SetRowSpan(this.pictureBox1, 2);
            this.pictureBox1.Size = new System.Drawing.Size(286, 104);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // LblNombre
            // 
            this.LblNombre.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblNombre.AutoSize = true;
            this.LblNombre.BackColor = System.Drawing.Color.Transparent;
            this.LblNombre.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblNombre.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblNombre.Location = new System.Drawing.Point(200, 124);
            this.LblNombre.Name = "LblNombre";
            this.LblNombre.Size = new System.Drawing.Size(89, 26);
            this.LblNombre.TabIndex = 1;
            this.LblNombre.Text = "Nombre:";
            // 
            // LblApellido
            // 
            this.LblApellido.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblApellido.AutoSize = true;
            this.LblApellido.BackColor = System.Drawing.Color.Transparent;
            this.LblApellido.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblApellido.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblApellido.Location = new System.Drawing.Point(199, 179);
            this.LblApellido.Name = "LblApellido";
            this.LblApellido.Size = new System.Drawing.Size(90, 26);
            this.LblApellido.TabIndex = 2;
            this.LblApellido.Text = "Apellido:";
            // 
            // LblCorreoElectronico
            // 
            this.LblCorreoElectronico.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblCorreoElectronico.AutoSize = true;
            this.LblCorreoElectronico.BackColor = System.Drawing.Color.Transparent;
            this.LblCorreoElectronico.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblCorreoElectronico.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblCorreoElectronico.Location = new System.Drawing.Point(224, 234);
            this.LblCorreoElectronico.Name = "LblCorreoElectronico";
            this.LblCorreoElectronico.Size = new System.Drawing.Size(65, 26);
            this.LblCorreoElectronico.TabIndex = 3;
            this.LblCorreoElectronico.Text = "Email:";
            // 
            // LblNombreUsuario
            // 
            this.LblNombreUsuario.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblNombreUsuario.AutoSize = true;
            this.LblNombreUsuario.BackColor = System.Drawing.Color.Transparent;
            this.LblNombreUsuario.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblNombreUsuario.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblNombreUsuario.Location = new System.Drawing.Point(205, 289);
            this.LblNombreUsuario.Name = "LblNombreUsuario";
            this.LblNombreUsuario.Size = new System.Drawing.Size(84, 26);
            this.LblNombreUsuario.TabIndex = 4;
            this.LblNombreUsuario.Text = "Usuario:";
            // 
            // LblContraseña
            // 
            this.LblContraseña.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblContraseña.AutoSize = true;
            this.LblContraseña.BackColor = System.Drawing.Color.Transparent;
            this.LblContraseña.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblContraseña.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblContraseña.Location = new System.Drawing.Point(174, 344);
            this.LblContraseña.Name = "LblContraseña";
            this.LblContraseña.Size = new System.Drawing.Size(115, 26);
            this.LblContraseña.TabIndex = 5;
            this.LblContraseña.Text = "Contraseña:";
            // 
            // LblconfContraseña
            // 
            this.LblconfContraseña.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblconfContraseña.AutoSize = true;
            this.LblconfContraseña.BackColor = System.Drawing.Color.Transparent;
            this.LblconfContraseña.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblconfContraseña.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblconfContraseña.Location = new System.Drawing.Point(83, 399);
            this.LblconfContraseña.Name = "LblconfContraseña";
            this.LblconfContraseña.Size = new System.Drawing.Size(206, 26);
            this.LblconfContraseña.TabIndex = 6;
            this.LblconfContraseña.Text = "Confirmar Contraseña:";
            // 
            // LblTipoUsuario
            // 
            this.LblTipoUsuario.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblTipoUsuario.AutoSize = true;
            this.LblTipoUsuario.BackColor = System.Drawing.Color.Transparent;
            this.LblTipoUsuario.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTipoUsuario.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblTipoUsuario.Location = new System.Drawing.Point(139, 454);
            this.LblTipoUsuario.Name = "LblTipoUsuario";
            this.LblTipoUsuario.Size = new System.Drawing.Size(150, 26);
            this.LblTipoUsuario.TabIndex = 7;
            this.LblTipoUsuario.Text = "Tipo de usuario:";
            // 
            // TxtNombre
            // 
            this.TxtNombre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtNombre.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtNombre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtNombre.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtNombre.Location = new System.Drawing.Point(295, 125);
            this.TxtNombre.Name = "TxtNombre";
            this.TxtNombre.Size = new System.Drawing.Size(286, 24);
            this.TxtNombre.TabIndex = 1;
            // 
            // TxtApellido
            // 
            this.TxtApellido.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtApellido.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtApellido.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtApellido.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtApellido.Location = new System.Drawing.Point(295, 180);
            this.TxtApellido.Name = "TxtApellido";
            this.TxtApellido.Size = new System.Drawing.Size(286, 24);
            this.TxtApellido.TabIndex = 2;
            // 
            // TxtEmail
            // 
            this.TxtEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtEmail.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtEmail.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtEmail.Location = new System.Drawing.Point(295, 235);
            this.TxtEmail.Name = "TxtEmail";
            this.TxtEmail.Size = new System.Drawing.Size(286, 24);
            this.TxtEmail.TabIndex = 3;
            // 
            // TxtUsuario
            // 
            this.TxtUsuario.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtUsuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtUsuario.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtUsuario.Location = new System.Drawing.Point(295, 290);
            this.TxtUsuario.Name = "TxtUsuario";
            this.TxtUsuario.Size = new System.Drawing.Size(286, 24);
            this.TxtUsuario.TabIndex = 4;
            // 
            // TxtContraseña
            // 
            this.TxtContraseña.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtContraseña.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtContraseña.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtContraseña.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtContraseña.Location = new System.Drawing.Point(295, 345);
            this.TxtContraseña.Name = "TxtContraseña";
            this.TxtContraseña.Size = new System.Drawing.Size(286, 24);
            this.TxtContraseña.TabIndex = 5;
            this.TxtContraseña.UseSystemPasswordChar = true;
            // 
            // TxtConfContraseña
            // 
            this.TxtConfContraseña.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtConfContraseña.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtConfContraseña.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtConfContraseña.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtConfContraseña.Location = new System.Drawing.Point(295, 400);
            this.TxtConfContraseña.Name = "TxtConfContraseña";
            this.TxtConfContraseña.Size = new System.Drawing.Size(286, 24);
            this.TxtConfContraseña.TabIndex = 6;
            this.TxtConfContraseña.UseSystemPasswordChar = true;
            // 
            // CbxTipoUsuario
            // 
            this.CbxTipoUsuario.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.CbxTipoUsuario.BackColor = System.Drawing.Color.WhiteSmoke;
            this.CbxTipoUsuario.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CbxTipoUsuario.FormattingEnabled = true;
            this.CbxTipoUsuario.Location = new System.Drawing.Point(295, 454);
            this.CbxTipoUsuario.Name = "CbxTipoUsuario";
            this.CbxTipoUsuario.Size = new System.Drawing.Size(286, 27);
            this.CbxTipoUsuario.TabIndex = 7;
            // 
            // BtnAceptar
            // 
            this.BtnAceptar.AutoSize = true;
            this.BtnAceptar.BackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnAceptar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnAceptar.FlatAppearance.BorderSize = 0;
            this.BtnAceptar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnAceptar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnAceptar.ForeColor = System.Drawing.SystemColors.Desktop;
            this.BtnAceptar.Location = new System.Drawing.Point(295, 498);
            this.BtnAceptar.Name = "BtnAceptar";
            this.BtnAceptar.Size = new System.Drawing.Size(286, 34);
            this.BtnAceptar.TabIndex = 15;
            this.BtnAceptar.Text = "Aceptar";
            this.BtnAceptar.UseVisualStyleBackColor = false;
            this.BtnAceptar.Click += new System.EventHandler(this.BtnAceptar_Click);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.AutoSize = true;
            this.BtnCancelar.BackColor = System.Drawing.Color.Pink;
            this.BtnCancelar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnCancelar.FlatAppearance.BorderSize = 0;
            this.BtnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCancelar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnCancelar.ForeColor = System.Drawing.SystemColors.Desktop;
            this.BtnCancelar.Location = new System.Drawing.Point(295, 553);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(286, 34);
            this.BtnCancelar.TabIndex = 16;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // FormDatosUsuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 610);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "FormDatosUsuarios";
            this.Text = "FormDatosUsuarios";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormDatosUsuarios_FormClosing);
            this.Load += new System.EventHandler(this.FormDatosUsuarios_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label LblNombre;
        private System.Windows.Forms.Label LblApellido;
        private System.Windows.Forms.Label LblCorreoElectronico;
        private System.Windows.Forms.Label LblNombreUsuario;
        private System.Windows.Forms.Label LblContraseña;
        private System.Windows.Forms.Label LblconfContraseña;
        private System.Windows.Forms.Label LblTipoUsuario;
        private System.Windows.Forms.TextBox TxtNombre;
        private System.Windows.Forms.TextBox TxtApellido;
        private System.Windows.Forms.TextBox TxtEmail;
        private System.Windows.Forms.TextBox TxtUsuario;
        private System.Windows.Forms.TextBox TxtContraseña;
        private System.Windows.Forms.TextBox TxtConfContraseña;
        private System.Windows.Forms.ComboBox CbxTipoUsuario;
        private System.Windows.Forms.Button BtnAceptar;
        private System.Windows.Forms.Button BtnCancelar;
    }
}