﻿
namespace SistemaGestorDePacientes
{
    partial class MantMedicos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.BtnCrearMedico = new System.Windows.Forms.Button();
            this.BtnEditarMedico = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.BtnDeseleccionar = new System.Windows.Forms.Button();
            this.BtnEliminarMedico = new System.Windows.Forms.Button();
            this.DgvMedico = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.opcionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salilrToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.volverAtrásToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LblMantMed = new System.Windows.Forms.Label();
            this.PbMedico = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvMedico)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbMedico)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.BackgroundImage = global::SistemaGestorDePacientes.Properties.Resources.abstract_geometric_hexagons_shape_medicine_science_concept_background_medical_ico;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.DgvMedico, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.LblMantMed, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.PbMedico, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.22846F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 1.685393F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.08614F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(918, 577);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(614, 184);
            this.label1.Name = "label1";
            this.tableLayoutPanel1.SetRowSpan(this.label1, 2);
            this.label1.Size = new System.Drawing.Size(301, 29);
            this.label1.TabIndex = 7;
            this.label1.Text = "Foto Perfil";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::SistemaGestorDePacientes.Properties.Resources.Artboard_2;
            this.pictureBox1.Location = new System.Drawing.Point(308, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.tableLayoutPanel1.SetRowSpan(this.pictureBox1, 2);
            this.pictureBox1.Size = new System.Drawing.Size(300, 178);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.BtnCrearMedico, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.BtnEditarMedico, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(308, 187);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(300, 86);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // BtnCrearMedico
            // 
            this.BtnCrearMedico.AutoSize = true;
            this.BtnCrearMedico.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnCrearMedico.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnCrearMedico.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.BtnCrearMedico.Location = new System.Drawing.Point(3, 3);
            this.BtnCrearMedico.Name = "BtnCrearMedico";
            this.BtnCrearMedico.Size = new System.Drawing.Size(294, 36);
            this.BtnCrearMedico.TabIndex = 1;
            this.BtnCrearMedico.Text = "Crear Nuevo Médico";
            this.BtnCrearMedico.UseVisualStyleBackColor = true;
            this.BtnCrearMedico.Click += new System.EventHandler(this.BtnCrearMedico_Click);
            // 
            // BtnEditarMedico
            // 
            this.BtnEditarMedico.AutoSize = true;
            this.BtnEditarMedico.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnEditarMedico.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnEditarMedico.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.BtnEditarMedico.Location = new System.Drawing.Point(3, 46);
            this.BtnEditarMedico.Name = "BtnEditarMedico";
            this.BtnEditarMedico.Size = new System.Drawing.Size(294, 36);
            this.BtnEditarMedico.TabIndex = 2;
            this.BtnEditarMedico.Text = "Editar Médico";
            this.BtnEditarMedico.UseVisualStyleBackColor = true;
            this.BtnEditarMedico.Click += new System.EventHandler(this.BtnEditarMedico_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.BtnDeseleccionar, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.BtnEliminarMedico, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(308, 279);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(300, 89);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // BtnDeseleccionar
            // 
            this.BtnDeseleccionar.AutoSize = true;
            this.BtnDeseleccionar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnDeseleccionar.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnDeseleccionar.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.BtnDeseleccionar.Location = new System.Drawing.Point(3, 3);
            this.BtnDeseleccionar.Name = "BtnDeseleccionar";
            this.BtnDeseleccionar.Size = new System.Drawing.Size(294, 37);
            this.BtnDeseleccionar.TabIndex = 3;
            this.BtnDeseleccionar.Text = "Deseleccionar";
            this.BtnDeseleccionar.UseVisualStyleBackColor = true;
            this.BtnDeseleccionar.Click += new System.EventHandler(this.BtnDeseleccionar_Click);
            // 
            // BtnEliminarMedico
            // 
            this.BtnEliminarMedico.AutoSize = true;
            this.BtnEliminarMedico.BackColor = System.Drawing.Color.Tomato;
            this.BtnEliminarMedico.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BtnEliminarMedico.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnEliminarMedico.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnEliminarMedico.Location = new System.Drawing.Point(3, 53);
            this.BtnEliminarMedico.Name = "BtnEliminarMedico";
            this.BtnEliminarMedico.Size = new System.Drawing.Size(294, 33);
            this.BtnEliminarMedico.TabIndex = 4;
            this.BtnEliminarMedico.Text = "Eliminar";
            this.BtnEliminarMedico.UseVisualStyleBackColor = false;
            this.BtnEliminarMedico.Click += new System.EventHandler(this.BtnEliminarMedico_Click);
            // 
            // DgvMedico
            // 
            this.DgvMedico.AllowUserToAddRows = false;
            this.DgvMedico.AllowUserToDeleteRows = false;
            this.DgvMedico.AllowUserToResizeColumns = false;
            this.DgvMedico.AllowUserToResizeRows = false;
            this.DgvMedico.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvMedico.BackgroundColor = System.Drawing.Color.MintCream;
            this.DgvMedico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.DgvMedico, 3);
            this.DgvMedico.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvMedico.Location = new System.Drawing.Point(3, 383);
            this.DgvMedico.MultiSelect = false;
            this.DgvMedico.Name = "DgvMedico";
            this.DgvMedico.ReadOnly = true;
            this.tableLayoutPanel1.SetRowSpan(this.DgvMedico, 2);
            this.DgvMedico.RowTemplate.Height = 25;
            this.DgvMedico.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvMedico.Size = new System.Drawing.Size(912, 191);
            this.DgvMedico.TabIndex = 3;
            this.DgvMedico.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvMedico_CellClick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.PowderBlue;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.opcionesToolStripMenuItem,
            this.volverAtrásToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(305, 27);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // opcionesToolStripMenuItem
            // 
            this.opcionesToolStripMenuItem.BackColor = System.Drawing.Color.PowderBlue;
            this.opcionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salilrToolStripMenuItem});
            this.opcionesToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.opcionesToolStripMenuItem.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.opcionesToolStripMenuItem.Name = "opcionesToolStripMenuItem";
            this.opcionesToolStripMenuItem.Size = new System.Drawing.Size(84, 23);
            this.opcionesToolStripMenuItem.Text = "Opciones";
            // 
            // salilrToolStripMenuItem
            // 
            this.salilrToolStripMenuItem.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.salilrToolStripMenuItem.Name = "salilrToolStripMenuItem";
            this.salilrToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.salilrToolStripMenuItem.Text = "Salir";
            this.salilrToolStripMenuItem.Click += new System.EventHandler(this.salilrToolStripMenuItem_Click);
            // 
            // volverAtrásToolStripMenuItem
            // 
            this.volverAtrásToolStripMenuItem.BackColor = System.Drawing.Color.PowderBlue;
            this.volverAtrásToolStripMenuItem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.volverAtrásToolStripMenuItem.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.volverAtrásToolStripMenuItem.Name = "volverAtrásToolStripMenuItem";
            this.volverAtrásToolStripMenuItem.Size = new System.Drawing.Size(122, 23);
            this.volverAtrásToolStripMenuItem.Text = "← Volver Atrás";
            this.volverAtrásToolStripMenuItem.Click += new System.EventHandler(this.volverAtrásToolStripMenuItem_Click);
            // 
            // LblMantMed
            // 
            this.LblMantMed.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LblMantMed.AutoSize = true;
            this.LblMantMed.BackColor = System.Drawing.Color.Transparent;
            this.LblMantMed.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblMantMed.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblMantMed.Location = new System.Drawing.Point(3, 92);
            this.LblMantMed.Name = "LblMantMed";
            this.tableLayoutPanel1.SetRowSpan(this.LblMantMed, 2);
            this.LblMantMed.Size = new System.Drawing.Size(299, 99);
            this.LblMantMed.TabIndex = 5;
            this.LblMantMed.Text = "Mantenimiento \r\nde\r\nMédicos";
            this.LblMantMed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PbMedico
            // 
            this.PbMedico.BackColor = System.Drawing.Color.MintCream;
            this.PbMedico.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PbMedico.Location = new System.Drawing.Point(614, 3);
            this.PbMedico.Name = "PbMedico";
            this.tableLayoutPanel1.SetRowSpan(this.PbMedico, 2);
            this.PbMedico.Size = new System.Drawing.Size(301, 178);
            this.PbMedico.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PbMedico.TabIndex = 6;
            this.PbMedico.TabStop = false;
            // 
            // MantMedicos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 577);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MantMedicos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MantMedicos";
            this.Load += new System.EventHandler(this.MantMedicos_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvMedico)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PbMedico)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.DataGridView DgvMedico;
        private System.Windows.Forms.Button BtnCrearMedico;
        private System.Windows.Forms.Button BtnEditarMedico;
        private System.Windows.Forms.Button BtnDeseleccionar;
        private System.Windows.Forms.Button BtnEliminarMedico;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem opcionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem volverAtrásToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salilrToolStripMenuItem;
        private System.Windows.Forms.Label LblMantMed;
        private System.Windows.Forms.PictureBox PbMedico;
        private System.Windows.Forms.Label label1;
    }
}