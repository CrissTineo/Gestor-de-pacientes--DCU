﻿using DBservicios.MirrorDB;
using ServiceLayer;
using SistemaGestorDePacientes.CrossClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SistemaGestorDePacientes
{
    public partial class VentanaVerRes : Form
    {
        ServicioRPL servRpl;
        public VentanaVerRes()
        {
            InitializeComponent();
            string connectionStrings = ConfigurationManager.ConnectionStrings["Default"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionStrings);

            servRpl = new ServicioRPL(connection);
        }
        #region Eventos
        private void BtnVolver_Click(object sender, EventArgs e)
        {
            Volver();
        }
        #endregion
        private void VentanaVerRes_FormClosing(object sender, FormClosingEventArgs e)
        {
            MantCita mCita = new MantCita();
            mCita.Show();
        }
        private void VentanaVerRes_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        #region Metodor

        private void Volver()
        {
            this.Close();
        }
        private void LoadData()
        {   
            DgvVres.DataSource = servRpl.GetResulListo(CroosIndex.indice);
            DgvVres.ClearSelection();
        }
        #endregion

        

       
    }
}
