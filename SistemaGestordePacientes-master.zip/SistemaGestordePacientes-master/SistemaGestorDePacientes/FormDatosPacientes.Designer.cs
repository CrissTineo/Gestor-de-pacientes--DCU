﻿
namespace SistemaGestorDePacientes
{
    partial class FormDatosPacientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TxtNombre = new System.Windows.Forms.TextBox();
            this.TxtApellido = new System.Windows.Forms.TextBox();
            this.TxtDireccion = new System.Windows.Forms.TextBox();
            this.TxtCedula = new System.Windows.Forms.TextBox();
            this.TxtAlergias = new System.Windows.Forms.TextBox();
            this.BtnSubirFoto = new System.Windows.Forms.Button();
            this.BtnAgregar = new System.Windows.Forms.Button();
            this.LblNombre = new System.Windows.Forms.Label();
            this.LblApellido = new System.Windows.Forms.Label();
            this.LblTel = new System.Windows.Forms.Label();
            this.LblDireccion = new System.Windows.Forms.Label();
            this.LblCedula = new System.Windows.Forms.Label();
            this.LblFecha = new System.Windows.Forms.Label();
            this.Lblfumador = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.CbxF = new System.Windows.Forms.ComboBox();
            this.MaskTxtFecha = new System.Windows.Forms.MaskedTextBox();
            this.MaskTxtTel = new System.Windows.Forms.MaskedTextBox();
            this.PicDialogo = new System.Windows.Forms.OpenFileDialog();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackgroundImage = global::SistemaGestorDePacientes.Properties.Resources.abstract_geometric_hexagons_shape_medicine_science_concept_background_medical_ico;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.TxtNombre, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.TxtApellido, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.TxtDireccion, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.TxtCedula, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.TxtAlergias, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.BtnSubirFoto, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.BtnAgregar, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.LblNombre, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.LblApellido, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.LblTel, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.LblDireccion, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.LblCedula, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.LblFecha, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.Lblfumador, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.BtnCancelar, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.CbxF, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.MaskTxtFecha, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.MaskTxtTel, 1, 4);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 14;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(866, 627);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::SistemaGestorDePacientes.Properties.Resources.Artboard_2;
            this.pictureBox1.Location = new System.Drawing.Point(291, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.tableLayoutPanel1.SetRowSpan(this.pictureBox1, 2);
            this.pictureBox1.Size = new System.Drawing.Size(282, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // TxtNombre
            // 
            this.TxtNombre.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtNombre.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtNombre.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtNombre.Location = new System.Drawing.Point(291, 104);
            this.TxtNombre.Name = "TxtNombre";
            this.TxtNombre.Size = new System.Drawing.Size(282, 27);
            this.TxtNombre.TabIndex = 1;
            // 
            // TxtApellido
            // 
            this.TxtApellido.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtApellido.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtApellido.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtApellido.Location = new System.Drawing.Point(291, 151);
            this.TxtApellido.Name = "TxtApellido";
            this.TxtApellido.Size = new System.Drawing.Size(282, 27);
            this.TxtApellido.TabIndex = 2;
            // 
            // TxtDireccion
            // 
            this.TxtDireccion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtDireccion.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtDireccion.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtDireccion.Location = new System.Drawing.Point(291, 245);
            this.TxtDireccion.Name = "TxtDireccion";
            this.TxtDireccion.Size = new System.Drawing.Size(282, 27);
            this.TxtDireccion.TabIndex = 4;
            // 
            // TxtCedula
            // 
            this.TxtCedula.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtCedula.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtCedula.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtCedula.Location = new System.Drawing.Point(291, 292);
            this.TxtCedula.Name = "TxtCedula";
            this.TxtCedula.Size = new System.Drawing.Size(282, 27);
            this.TxtCedula.TabIndex = 5;
            // 
            // TxtAlergias
            // 
            this.TxtAlergias.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TxtAlergias.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TxtAlergias.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TxtAlergias.Location = new System.Drawing.Point(291, 433);
            this.TxtAlergias.Name = "TxtAlergias";
            this.TxtAlergias.Size = new System.Drawing.Size(282, 27);
            this.TxtAlergias.TabIndex = 8;
            // 
            // BtnSubirFoto
            // 
            this.BtnSubirFoto.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BtnSubirFoto.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnSubirFoto.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnSubirFoto.Location = new System.Drawing.Point(291, 473);
            this.BtnSubirFoto.Name = "BtnSubirFoto";
            this.BtnSubirFoto.Size = new System.Drawing.Size(282, 37);
            this.BtnSubirFoto.TabIndex = 9;
            this.BtnSubirFoto.Text = "◙ Subir Foto";
            this.BtnSubirFoto.UseVisualStyleBackColor = false;
            this.BtnSubirFoto.Click += new System.EventHandler(this.BtnSubirFoto_Click);
            // 
            // BtnAgregar
            // 
            this.BtnAgregar.BackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnAgregar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnAgregar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnAgregar.ForeColor = System.Drawing.SystemColors.Desktop;
            this.BtnAgregar.Location = new System.Drawing.Point(291, 520);
            this.BtnAgregar.Name = "BtnAgregar";
            this.BtnAgregar.Size = new System.Drawing.Size(282, 40);
            this.BtnAgregar.TabIndex = 10;
            this.BtnAgregar.Text = "Aceptar";
            this.BtnAgregar.UseVisualStyleBackColor = false;
            this.BtnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);
            // 
            // LblNombre
            // 
            this.LblNombre.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblNombre.AutoSize = true;
            this.LblNombre.BackColor = System.Drawing.Color.Transparent;
            this.LblNombre.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblNombre.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblNombre.Location = new System.Drawing.Point(196, 104);
            this.LblNombre.Name = "LblNombre";
            this.LblNombre.Size = new System.Drawing.Size(89, 26);
            this.LblNombre.TabIndex = 11;
            this.LblNombre.Text = "Nombre:";
            // 
            // LblApellido
            // 
            this.LblApellido.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblApellido.AutoSize = true;
            this.LblApellido.BackColor = System.Drawing.Color.Transparent;
            this.LblApellido.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblApellido.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblApellido.Location = new System.Drawing.Point(195, 151);
            this.LblApellido.Name = "LblApellido";
            this.LblApellido.Size = new System.Drawing.Size(90, 26);
            this.LblApellido.TabIndex = 12;
            this.LblApellido.Text = "Apellido:";
            // 
            // LblTel
            // 
            this.LblTel.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblTel.AutoSize = true;
            this.LblTel.BackColor = System.Drawing.Color.Transparent;
            this.LblTel.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblTel.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblTel.Location = new System.Drawing.Point(192, 198);
            this.LblTel.Name = "LblTel";
            this.LblTel.Size = new System.Drawing.Size(93, 26);
            this.LblTel.TabIndex = 13;
            this.LblTel.Text = "Teléfono:";
            // 
            // LblDireccion
            // 
            this.LblDireccion.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblDireccion.AutoSize = true;
            this.LblDireccion.BackColor = System.Drawing.Color.Transparent;
            this.LblDireccion.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblDireccion.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblDireccion.Location = new System.Drawing.Point(186, 245);
            this.LblDireccion.Name = "LblDireccion";
            this.LblDireccion.Size = new System.Drawing.Size(99, 26);
            this.LblDireccion.TabIndex = 14;
            this.LblDireccion.Text = "Dirección:";
            // 
            // LblCedula
            // 
            this.LblCedula.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblCedula.AutoSize = true;
            this.LblCedula.BackColor = System.Drawing.Color.Transparent;
            this.LblCedula.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblCedula.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblCedula.Location = new System.Drawing.Point(208, 292);
            this.LblCedula.Name = "LblCedula";
            this.LblCedula.Size = new System.Drawing.Size(77, 26);
            this.LblCedula.TabIndex = 15;
            this.LblCedula.Text = "Cédula:";
            // 
            // LblFecha
            // 
            this.LblFecha.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.LblFecha.AutoSize = true;
            this.LblFecha.BackColor = System.Drawing.Color.Transparent;
            this.LblFecha.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblFecha.ForeColor = System.Drawing.Color.MidnightBlue;
            this.LblFecha.Location = new System.Drawing.Point(82, 339);
            this.LblFecha.Name = "LblFecha";
            this.LblFecha.Size = new System.Drawing.Size(203, 26);
            this.LblFecha.TabIndex = 16;
            this.LblFecha.Text = "Fecha De Nacimiento:";
            // 
            // Lblfumador
            // 
            this.Lblfumador.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.Lblfumador.AutoSize = true;
            this.Lblfumador.BackColor = System.Drawing.Color.Transparent;
            this.Lblfumador.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lblfumador.ForeColor = System.Drawing.Color.MidnightBlue;
            this.Lblfumador.Location = new System.Drawing.Point(186, 386);
            this.Lblfumador.Name = "Lblfumador";
            this.Lblfumador.Size = new System.Drawing.Size(99, 26);
            this.Lblfumador.TabIndex = 17;
            this.Lblfumador.Text = "Fumador?";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(194, 433);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 26);
            this.label1.TabIndex = 18;
            this.label1.Text = "Alergias?";
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.BackColor = System.Drawing.Color.Pink;
            this.BtnCancelar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCancelar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnCancelar.ForeColor = System.Drawing.SystemColors.Desktop;
            this.BtnCancelar.Location = new System.Drawing.Point(291, 567);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(282, 37);
            this.BtnCancelar.TabIndex = 11;
            this.BtnCancelar.Text = "Aceptar";
            this.BtnCancelar.UseVisualStyleBackColor = false;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // CbxF
            // 
            this.CbxF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.CbxF.FormattingEnabled = true;
            this.CbxF.Location = new System.Drawing.Point(291, 388);
            this.CbxF.Name = "CbxF";
            this.CbxF.Size = new System.Drawing.Size(282, 23);
            this.CbxF.TabIndex = 7;
            // 
            // MaskTxtFecha
            // 
            this.MaskTxtFecha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.MaskTxtFecha.Location = new System.Drawing.Point(291, 341);
            this.MaskTxtFecha.Mask = "00-00-0000";
            this.MaskTxtFecha.Name = "MaskTxtFecha";
            this.MaskTxtFecha.Size = new System.Drawing.Size(282, 23);
            this.MaskTxtFecha.TabIndex = 6;
            // 
            // MaskTxtTel
            // 
            this.MaskTxtTel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.MaskTxtTel.Location = new System.Drawing.Point(291, 200);
            this.MaskTxtTel.Mask = "(999)000-0000";
            this.MaskTxtTel.Name = "MaskTxtTel";
            this.MaskTxtTel.Size = new System.Drawing.Size(282, 23);
            this.MaskTxtTel.TabIndex = 3;
            // 
            // PicDialogo
            // 
            this.PicDialogo.FileName = "openFileDialog1";
            // 
            // FormDatosPacientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 627);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "FormDatosPacientes";
            this.Text = "FormDatosPacientes";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormDatosPacientes_FormClosing);
            this.Load += new System.EventHandler(this.FormDatosPacientes_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox TxtNombre;
        private System.Windows.Forms.TextBox TxtApellido;
        private System.Windows.Forms.TextBox TxtDireccion;
        private System.Windows.Forms.TextBox TxtCedula;
        private System.Windows.Forms.TextBox TxtAlergias;
        private System.Windows.Forms.Button BtnSubirFoto;
        private System.Windows.Forms.Button BtnAgregar;
        private System.Windows.Forms.Label LblNombre;
        private System.Windows.Forms.Label LblApellido;
        private System.Windows.Forms.Label LblTel;
        private System.Windows.Forms.Label LblDireccion;
        private System.Windows.Forms.Label LblCedula;
        private System.Windows.Forms.Label LblFecha;
        private System.Windows.Forms.Label Lblfumador;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.ComboBox CbxF;
        private System.Windows.Forms.MaskedTextBox MaskTxtFecha;
        private System.Windows.Forms.MaskedTextBox MaskTxtTel;
        private System.Windows.Forms.OpenFileDialog PicDialogo;
    }
}