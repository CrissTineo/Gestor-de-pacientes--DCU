﻿
namespace SistemaGestorDePacientes
{
    partial class VentanaRL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.DgvRl = new System.Windows.Forms.DataGridView();
            this.LblRl = new System.Windows.Forms.Label();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnCompletar = new System.Windows.Forms.Button();
            this.BtnDeseleccionar = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvRl)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.BackgroundImage = global::SistemaGestorDePacientes.Properties.Resources.abstract_geometric_hexagons_shape_medicine_science_concept_background_medical_ico;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.37733F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.62468F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19.996F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.37453F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.62747F));
            this.tableLayoutPanel1.Controls.Add(this.DgvRl, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.LblRl, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnCancelar, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnCompletar, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.BtnDeseleccionar, 2, 3);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.22F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.78F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1046, 538);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // DgvRl
            // 
            this.DgvRl.AllowUserToAddRows = false;
            this.DgvRl.AllowUserToDeleteRows = false;
            this.DgvRl.AllowUserToResizeColumns = false;
            this.DgvRl.AllowUserToResizeRows = false;
            this.DgvRl.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvRl.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DgvRl.BackgroundColor = System.Drawing.Color.MintCream;
            this.DgvRl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tableLayoutPanel1.SetColumnSpan(this.DgvRl, 3);
            this.DgvRl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvRl.Location = new System.Drawing.Point(142, 154);
            this.DgvRl.MultiSelect = false;
            this.DgvRl.Name = "DgvRl";
            this.DgvRl.ReadOnly = true;
            this.DgvRl.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this.tableLayoutPanel1.SetRowSpan(this.DgvRl, 2);
            this.DgvRl.RowTemplate.Height = 25;
            this.DgvRl.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvRl.Size = new System.Drawing.Size(767, 164);
            this.DgvRl.TabIndex = 0;
            this.DgvRl.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvRl_CellClick);
            // 
            // LblRl
            // 
            this.LblRl.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.LblRl, 3);
            this.LblRl.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.LblRl.Font = new System.Drawing.Font("Calibri", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblRl.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.LblRl.Location = new System.Drawing.Point(142, 109);
            this.LblRl.Name = "LblRl";
            this.LblRl.Size = new System.Drawing.Size(767, 42);
            this.LblRl.TabIndex = 1;
            this.LblRl.Text = "Listado De Resultados";
            this.LblRl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.AutoSize = true;
            this.BtnCancelar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnCancelar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnCancelar.ForeColor = System.Drawing.Color.Crimson;
            this.BtnCancelar.Location = new System.Drawing.Point(142, 324);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(272, 39);
            this.BtnCancelar.TabIndex = 2;
            this.BtnCancelar.Text = "Cerrar";
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // BtnCompletar
            // 
            this.BtnCompletar.AutoSize = true;
            this.BtnCompletar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnCompletar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnCompletar.ForeColor = System.Drawing.Color.Navy;
            this.BtnCompletar.Location = new System.Drawing.Point(629, 324);
            this.BtnCompletar.Name = "BtnCompletar";
            this.BtnCompletar.Size = new System.Drawing.Size(280, 39);
            this.BtnCompletar.TabIndex = 3;
            this.BtnCompletar.Text = "Completar";
            this.BtnCompletar.UseVisualStyleBackColor = true;
            this.BtnCompletar.Visible = false;
            this.BtnCompletar.Click += new System.EventHandler(this.BtnCompletar_Click);
            // 
            // BtnDeseleccionar
            // 
            this.BtnDeseleccionar.AutoSize = true;
            this.BtnDeseleccionar.Dock = System.Windows.Forms.DockStyle.Top;
            this.BtnDeseleccionar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BtnDeseleccionar.ForeColor = System.Drawing.Color.Black;
            this.BtnDeseleccionar.Location = new System.Drawing.Point(420, 324);
            this.BtnDeseleccionar.Name = "BtnDeseleccionar";
            this.BtnDeseleccionar.Size = new System.Drawing.Size(203, 39);
            this.BtnDeseleccionar.TabIndex = 4;
            this.BtnDeseleccionar.Text = "Deseleccionar";
            this.BtnDeseleccionar.UseVisualStyleBackColor = true;
            this.BtnDeseleccionar.Visible = false;
            this.BtnDeseleccionar.Click += new System.EventHandler(this.BtnDeseleccionar_Click);
            // 
            // VentanaRL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1046, 538);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "VentanaRL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VentanaRL";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.VentanaRL_FormClosing);
            this.Load += new System.EventHandler(this.VentanaRL_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvRl)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView DgvRl;
        private System.Windows.Forms.Label LblRl;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button BtnCompletar;
        private System.Windows.Forms.Button BtnDeseleccionar;
    }
}